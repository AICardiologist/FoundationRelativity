# Reproducibility Details — Paper 54

**DOI:** [10.5281/zenodo.18732964](https://doi.org/10.5281/zenodo.18732964)

## Environment

- **Lean 4 version:** leanprover/lean4:v4.29.0-rc1 (pinned in `lean-toolchain`)
- **Mathlib:** resolved via `lakefile.lean` from `https://github.com/leanprover-community/mathlib4` (commit pinned in `lake-manifest.json`)
- **LaTeX:** any standard TeX distribution (TeX Live, TinyTeX, MiKTeX) with `pdflatex`

## Reproducing the Lean Build

```bash
cd P54_BlochKatoDPT
lake build
```

On first build, Mathlib will be downloaded and compiled (this may take 30-60 minutes depending on hardware and cache availability). Subsequent builds are incremental.

Expected output: 0 errors, 0 warnings, 0 sorry.

## Reproducing the Paper

```bash
pdflatex paper54.tex
pdflatex paper54.tex
pdflatex paper54.tex
```

Three passes ensure cross-references and table of contents are fully resolved.

## Axiom Verification

After building, the Lean kernel has verified:

| Theorem | Principled Axioms Used | Sorry | Status |
|---------|----------------------|-------|--------|
| `lfunction_eval_computable` (A(i)) | `analytic_eval_computable` | 0 | Load-bearing |
| `ord_vanishing_requires_LPO` (A(ii)) | `zero_test_requires_LPO` | 0 | Load-bearing |
| `axiom2_realized` (B) | `deligne_weil_I` | 0 | Load-bearing |
| `deligne_period_archimedean` (C(i)) | `hodge_riemann_positive_definite` | 0 | Load-bearing |
| `beilinson_regulator_archimedean` (C(ii)) | `beilinson_height_positive_definite` | 0 | Load-bearing (conjectural) |
| `axiom1_fails_mixed` (D) | `ext1_not_decidable` | 0 | Load-bearing |
| `no_padic_polarization` (E) | `u_invariant_Qp` | 0 | Load-bearing |
| `prior_calibrations_all_succeed` | **None** (proved by `decide`) | 0 | Full proof |
| `paper54_is_first_partial` | **None** (proved by `decide`) | 0 | Full proof |

Total: 7 principled axioms, 0 sorry gaps.

## Classical.choice Audit

The infrastructure axiom `Classical.choice` appears in all results due to Mathlib's construction of R and C as Cauchy completions. This is an infrastructure artifact; the constructive stratification is established by proof content (cf. Paper 10, Methodology). Critically, `Classical.dec` does not appear in any theorem.

## Formalization Architecture

The formalization uses 8 modules (1,141 lines total):

| Module | Lines | Content |
|--------|-------|---------|
| DPTCalibration | 162 | Calibration record type, Papers 45-49 stubs |
| LPOIsolation | 173 | Theorem A (LPO isolation) |
| Axiom2Realization | 104 | Theorem B (Deligne Weil I) |
| Axiom3PartialRealization | 125 | Theorem C (Hodge-Riemann + Beilinson) |
| Axiom1Failure | 112 | Theorem D (Ext^1 undecidability) |
| TamagawaObstruction | 155 | Theorem E (u-invariant) |
| CalibrationVerdict | 145 | Theorem F, comparison table |
| DescentDiagram | 142 | Descent with fracture points |

## AI Assistance

The Lean 4 formalization was produced using AI code generation (Claude Code, Opus 4.6) under human direction. All mathematical content was specified by the author; every theorem is verified by the Lean 4 type checker.
