# Reproducibility Details — Paper 55

**DOI:** [10.5281/zenodo.18718136](https://doi.org/10.5281/zenodo.18718136)

## Environment

- **Lean 4 version:** leanprover/lean4:v4.29.0-rc1 (pinned in `lean-toolchain`)
- **Mathlib:** resolved via `lakefile.lean` from `https://github.com/leanprover-community/mathlib4` (commit pinned in `lake-manifest.json`)
- **LaTeX:** any standard TeX distribution (TeX Live, TinyTeX, MiKTeX) with `pdflatex`

## Reproducing the Lean Build

```bash
cd P55_GoedelConjD
lake build
```

On first build, Mathlib will be downloaded and compiled (this may take 30-60 minutes depending on hardware and cache availability). Subsequent builds are incremental.

Expected output: 0 errors, 0 warnings, 0 sorry.

The `#print axioms` commands in `Main.lean` verify the axiom profiles of each theorem at build time.

## Reproducing the Paper

```bash
pdflatex paper55_goedel_conj_d.tex
pdflatex paper55_goedel_conj_d.tex
```

Two passes ensure cross-references and table of contents are fully resolved.

## Axiom Verification

After building, the Lean kernel has verified:

| Theorem | Custom Axioms | Classical.choice |
|---------|---------------|-----------------|
| `pi02_is_arithmetical` | None | No |
| `arithmetical_is_sigma12` | None | No |
| `sigma12_is_shoenfield_absolute` | `shoenfield_absoluteness` | No |
| `pi02_cohen_immune` | `shoenfield_absoluteness` | No |
| `conjectureD_arithmetical` | `conjectureD_is_pi02` | No |
| `conjectureD_cohen_immune` | Both | No |
| `goedel_independent_witness` | None | No |
| `goedel_independent_unprovable` | None | No |

Eight of ten theorems use no axioms at all — they are pure logical implications. The remaining two (`conjectureD_arithmetical` and `conjectureD_cohen_immune`) accept the mathematical input (computability of cycle classes) and Shoenfield's theorem as axioms.

## AI Assistance

The Lean 4 formalization was produced using AI code generation (Claude Code, Opus 4.6) under human direction. All mathematical content was specified by the author; every theorem is verified by the Lean 4 type checker.
