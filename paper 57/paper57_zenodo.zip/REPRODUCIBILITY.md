# Reproducibility Details — Paper 57

**DOI:** [10.5281/zenodo.18734430](https://doi.org/10.5281/zenodo.18734430)

## Environment

- **Lean 4 version:** leanprover/lean4:v4.29.0-rc1 (pinned in `lean-toolchain`)
- **Mathlib:** resolved via `lakefile.lean` from `https://github.com/leanprover-community/mathlib4` (commit pinned in `lake-manifest.json`)
- **LaTeX:** any standard TeX distribution (TeX Live, TinyTeX, MiKTeX) with `pdflatex`

## Reproducing the Lean Build

```bash
cd P57_CompleteClassNumber1
lake build
```

On first build, Mathlib will be downloaded and compiled (this may take 30-60 minutes depending on hardware and cache availability). Subsequent builds are incremental.

Expected output: 0 errors, 0 warnings, 0 sorry.

## Reproducing the Paper

```bash
pdflatex paper57.tex
pdflatex paper57.tex
pdflatex paper57.tex
```

Three passes ensure cross-references and table of contents are fully resolved.

## Axiom Verification

After building, the Lean kernel has verified:

| Axiom | Source | Module |
|-------|--------|--------|
| `weil_class_degree_eq_conductor` | Geometric: correspondence degree = conductor | GramMatrixDerivation |

Total: 1 principled axiom, 0 sorry gaps.

All other content is purely computational: 9 trace matrix determinants (`native_decide`), 9 Gram matrix verifications (`norm_num`), 9 d₀² = disc(F) checks (`native_decide`), completeness and pattern checks (`native_decide`).

## Classical.choice Audit

The formalization imports Mathlib only for `Matrix.det` and `native_decide` infrastructure. No use of `Classical.choice` appears in the proof terms. The only Lean infrastructure axioms used are `propext` and `Quot.sound`. The BISH classification is genuine at the formalization level.

## Formalization Architecture

The formalization uses 3 active modules (~918 lines) + 1 deprecated module:

| Module | Lines | Content |
|--------|-------|---------|
| NumberFieldData | 206 | 9 trace matrices, disc(F) via Newton's identities, native_decide |
| GramMatrixDerivation | 418 | Conductor-based proof, 9 Gram lattice verifications, counterexample |
| PatternAndVerdict | 294 | 9-row pattern table, completeness, HR checks |

One deprecated module (`GramMatrixDerivation_v3_deprecated.lean`) is retained for correction history reproducibility.

## AI Assistance

The Lean 4 formalization was produced using AI code generation (Claude Code, Opus 4.6) under human direction. All mathematical content was specified by the author; every theorem is verified by the Lean 4 type checker.
