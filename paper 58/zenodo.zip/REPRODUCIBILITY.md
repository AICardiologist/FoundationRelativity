# Reproducibility Guide — Paper 58

## Quick Start

```bash
cd P58_ClassNumber
lake exe cache get    # download prebuilt Mathlib (~5 min)
lake build            # build Paper 58 modules (~2 min)
```

Expected output: **zero errors, zero warnings, zero sorry**.

## Environment

| Component | Version |
|-----------|---------|
| Lean 4 | `leanprover/lean4:v4.29.0-rc1` (pinned in `lean-toolchain`) |
| Mathlib | Commit pinned in `lake-manifest.json` |
| OS | Any platform supporting Lean 4 (tested on macOS) |

## What Gets Verified

### Zero Custom Axioms

The corrected formula `h * Nm(a) = f` is a **proof obligation** (a field in the `WeilLatticeData` structure), not a global axiom.  Each instance proves it by `native_decide`.

`#print axioms paper58_summary_K5` produces only:
- `propext` (Lean kernel)
- `Classical.choice` (Mathlib infrastructure for `Matrix.det`)
- `Quot.sound` (Lean kernel)

### Key Theorems

| Theorem | What it verifies | Tactic |
|---------|-----------------|--------|
| `gram_K5_f7_match` | det(G) = 49 * 20 = 980 for f=7 | `native_decide` |
| `gram_K5_f9_match` | det(G) = 81 * 20 = 1620 for f=9 | `native_decide` |
| `gram_K5_f61_match` | det(G) = 3721 * 20 = 74420 for f=61 | `native_decide` |
| `gram_K5_f163_match` | det(G) = 26569 * 20 = 531380 for f=163 | `native_decide` |
| `not_rational_norm_mod5` | f equiv 2,3 mod 5 => no norm | infinite descent |
| `seven_not_rational_norm_K5` | 7 not a norm in Q(sqrt(-5)) | mod-5 descent |
| `gram_volume_invariant` | Free and non-free templates give same det | `ring` |
| `paper58_summary_K5` | 9 total, 4 split, 5 inert | `native_decide` |

### Module Structure

```
Papers/P58_ClassNumber/
  Defs.lean                110 lines   Core structures
  GramMatrix.lean          119 lines   Template Gram matrices, determinants
  NormObstruction.lean     235 lines   Mod-5 descent, norm witnesses
  ClassNumberExamples.lean 179 lines   WeilLatticeData for all 9 conductors
  Completeness.lean         83 lines   VerifiedPair, summary theorem
  Main.lean                 79 lines   Imports, #print axioms audit
                           ---
  Total                    805 lines   0 sorry, 0 custom axioms
```

## LaTeX Paper

```bash
pdflatex paper58.tex && pdflatex paper58.tex
```

Produces `paper58.pdf` (9 pages).

## Troubleshooting

- **Mathlib download slow:** `lake exe cache get` requires ~2 GB download.  Use a fast connection.
- **Build fails:** Ensure exact Lean version matches `lean-toolchain`.  Run `elan install leanprover/lean4:v4.29.0-rc1` if needed.
- **Memory:** Mathlib compilation may require 8+ GB RAM.  Using `lake exe cache get` avoids recompilation.

## Citation

If you use this formalization, please cite:

```
P. C.-K. Lee, "Class Number Correction for Exotic Weil Classes on CM Abelian Fourfolds,"
Paper 58, Constructive Reverse Mathematics Series, Zenodo, 2026.
DOI: 10.5281/zenodo.18734718
```
