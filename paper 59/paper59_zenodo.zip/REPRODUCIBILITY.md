# Reproducibility Guide — Paper 59

## Quick Start

```bash
cd P59_DeRhamDecidability
lake exe cache get    # download prebuilt Mathlib (~5 min)
lake build            # build Paper 59 modules (~2 min)
```

Expected output: **zero errors, zero warnings, zero sorry**.

## Environment

| Component | Version |
|-----------|---------|
| Lean 4 | `leanprover/lean4:v4.29.0-rc1` (pinned in `lean-toolchain`) |
| Mathlib | Commit pinned in `lake-manifest.json` |
| OS | Any platform supporting Lean 4 (tested on macOS) |

## What Gets Verified

### Zero Custom Axioms

The precision bound N_M = v_p(#E(F_p)) is a **proof obligation** (a field in the `VerifiedBound` structure), not a global axiom.  Each of the 24 entries proves its bound by `norm_num` and `simp`.

`#print axioms table_length` produces only:
- `propext` (Lean kernel)
- `Classical.choice` (Mathlib infrastructure)
- `Quot.sound` (Lean kernel)

### Key Theorems

| Theorem | What it verifies | Tactic |
|---------|-----------------|--------|
| `hasse_implies_positive` | 1 - a_p + p > 0 from Hasse bound | `nlinarith` |
| `supersingular_no_precision_loss` | a_p = 0 => p does not divide (1+p) | `linarith` |
| `ordinary_non_anomalous` | p ∤ (1-a_p) => p ∤ (1-a_p+p) | algebraic |
| `table_length` | 24 entries in verification table | `native_decide` |
| `anomalous_count` | 4 anomalous entries (N_M >= 1) | `native_decide` |
| `generic_count` | 20 generic entries (N_M = 0) | `native_decide` |
| `max_precision_loss` | Maximum N_M = 2 | `native_decide` |

### Module Structure

```
Papers/P59_DeRhamDecidability/
  Defs.lean                 74 lines   Core structures, Hasse bound
  PadicVal.lean             54 lines   Divisibility-based valuation
  VerificationTable.lean   272 lines   24 verified precision bound entries
  WeakAdmissibility.lean   128 lines   Hasse => positivity theorems
  Interpretation.lean      185 lines   CRM interpretation, Axiom 5
  Main.lean                 49 lines   Assembly, #print axioms audit
                           ---
  Total                    762 lines   0 sorry, 0 custom axioms
```

## LaTeX Paper

```bash
pdflatex paper59_de_rham_decidability.tex && pdflatex paper59_de_rham_decidability.tex
```

Produces `paper59_de_rham_decidability.pdf` (14 pages).

## Troubleshooting

- **Mathlib download slow:** `lake exe cache get` requires ~2 GB download.  Use a fast connection.
- **Build fails:** Ensure exact Lean version matches `lean-toolchain`.  Run `elan install leanprover/lean4:v4.29.0-rc1` if needed.
- **Memory:** Mathlib compilation may require 8+ GB RAM.  Using `lake exe cache get` avoids recompilation.

## Citation

If you use this formalization, please cite:

```
P. C.-K. Lee, "De Rham Decidability and DPT Completeness — The p-adic Precision Bound,"
Paper 59, Constructive Reverse Mathematics Series, Zenodo, 2026.
DOI: 10.5281/zenodo.18735931
```
