# Reproducibility Details — Paper 55

**DOI:** [10.5281/zenodo.18733731](https://doi.org/10.5281/zenodo.18733731)

## Environment

- **Lean 4 version:** leanprover/lean4:v4.29.0-rc1 (pinned in `lean-toolchain`)
- **Mathlib:** resolved via `lakefile.lean` from `https://github.com/leanprover-community/mathlib4` (commit pinned in `lake-manifest.json`)
- **LaTeX:** any standard TeX distribution (TeX Live, TinyTeX, MiKTeX) with `pdflatex`

## Reproducing the Lean Build

```bash
cd P55_K3KugaSatakeDPT
lake build
```

On first build, Mathlib will be downloaded and compiled (this may take 30-60 minutes depending on hardware and cache availability). Subsequent builds are incremental.

Expected output: 0 errors, 0 warnings, 0 sorry.

## Reproducing the Paper

```bash
pdflatex paper55.tex
pdflatex paper55.tex
pdflatex paper55.tex
```

Three passes ensure cross-references and table of contents are fully resolved.

## Axiom Verification

After building, the Lean kernel has verified:

| Theorem | Principled Axioms Used | Sorry | Status |
|---------|----------------------|-------|--------|
| `axiom1_transfer` (A) | `andre_motivated_cycle`, `lieberman_hom_num_abelian`, `matsusaka_conj_d_surfaces` | 0 | Load-bearing |
| `axiom2_independence` (B) | `deligne_weil_I` | 0 | Load-bearing |
| `axiom3_via_kuga_satake` (C) | `clifford_trace_positive_definite`, `rosati_from_clifford_trace` | 0 | Load-bearing |
| `supersingular_bypass` (D) | `tate_supersingular_direct` | 0 | Load-bearing |
| `k3_lefschetz_exhaustive` (E) | `lefschetz_1_1` | 0 | Load-bearing |
| `cy3_axiom1_failure` (F) | `hodge_riemann_weight3` | 0 | Load-bearing |
| `calibration_summary` (G) | **None** (proved by `decide`) | 0 | Full proof |

Total: 9 principled axioms, 0 sorry gaps.

## Classical.choice Audit

The formalization does not import Mathlib. All definitions and proofs are self-contained. The only Lean axioms used are `propext` and `Quot.sound`, plus the 9 principled axioms and ~40 structural stubs. No instance of `Classical.choice` appears. The formalization is constructive modulo the declared axioms.

## Formalization Architecture

The formalization uses 8 modules (1,131 lines total):

| Module | Lines | Content |
|--------|-------|---------|
| K3DPTCalibration | 152 | K3 types, calibration record |
| Axiom1Transfer | 136 | Theorem A (motivated cycle transfer) |
| Axiom2Independence | 101 | Theorem B (Deligne Weil I) |
| Axiom3KugaSatake | 127 | Theorem C (KS provides Axiom 3) |
| SupersingularBypass | 109 | Theorem D (supersingular bypass) |
| NoPicardBoundary | 138 | Theorem E (no Picard boundary) |
| CY3Correction | 159 | Theorem F (CY3 correction) |
| K3CalibrationVerdict | 209 | Theorem G (7-row comparison table) |

## AI Assistance

The Lean 4 formalization was produced using AI code generation (Claude Code, Opus 4.6) under human direction. All mathematical content was specified by the author; every theorem is verified by the Lean 4 type checker.
