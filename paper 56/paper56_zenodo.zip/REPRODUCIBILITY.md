# Reproducibility Details — Paper 56

**DOI:** [10.5281/zenodo.18734021](https://doi.org/10.5281/zenodo.18734021)

## Environment

- **Lean 4 version:** leanprover/lean4:v4.29.0-rc1 (pinned in `lean-toolchain`)
- **Mathlib:** resolved via `lakefile.lean` from `https://github.com/leanprover-community/mathlib4` (commit pinned in `lake-manifest.json`)
- **LaTeX:** any standard TeX distribution (TeX Live, TinyTeX, MiKTeX) with `pdflatex`

## Reproducing the Lean Build

```bash
cd P56_ExoticWeilSelfInt
lake build
```

On first build, Mathlib will be downloaded and compiled (this may take 30-60 minutes depending on hardware and cache availability). Subsequent builds are incremental.

Expected output: 0 errors, 0 warnings, 0 sorry.

## Reproducing the Paper

```bash
pdflatex paper56.tex
pdflatex paper56.tex
pdflatex paper56.tex
```

Three passes ensure cross-references and table of contents are fully resolved.

## Axiom Verification

After building, the Lean kernel has verified:

| Axiom | Source | Module |
|-------|--------|--------|
| `milne_weil_dim` | Milne 1999, Lemma 1.3 | WeilLattice |
| `exotic_not_lefschetz` | Anderson 1993; Milne 1999 | WeilLattice |
| `cm_polarization_threefold` | Shimura 1998, Ch. II | PolarizationDet |
| `det_product_ex1` | CM arithmetic (Example 1) | PolarizationDet |
| `det_product_ex2` | CM arithmetic (Example 2) | PolarizationDet |
| `det_product_ex3` | CM arithmetic (Example 3) | PolarizationDet |
| `schoen_algebraicity_ex1` | Schoen 1998, Thm 0.2 | SchoenAlgebraicity |
| `schoen_algebraicity_ex2` | Schoen 1998, Thm 0.2 | SchoenAlgebraicity |
| `schoen_algebraicity_ex3` | Schoen 1998, Thm 0.2 | SchoenAlgebraicity |
| `weil_class_degree_eq_conductor` | Geometric (correspondence degree = conductor) | GramMatrixDerivation |

Total: 10 principled axioms, 0 sorry gaps.

Full census: ~15 opaque type stubs, ~10 structural helpers, 10 principled axioms = ~35 total.

## Classical.choice Audit

The formalization does not import Mathlib's `Classical` module. All definitions and proofs are constructive modulo the declared principled axioms. The only Lean infrastructure axioms used are `propext` and `Quot.sound`. No instance of `Classical.choice` appears. The BISH classification is genuine at the formalization level.

## Formalization Architecture

The formalization uses 9 active modules (~1,340 lines) + 2 deprecated modules:

| Module | Lines | Content |
|--------|-------|---------|
| NumberFieldData | 163 | Trace matrices, Newton's identities, native_decide determinants |
| WeilLattice | 102 | Milne dimension, exotic not Lefschetz (2 principled axioms) |
| PolarizationDet | 126 | CM polarization determinants (4 principled axioms) |
| SelfIntersection | 146 | Self-intersection values, structural helpers |
| HodgeRiemann | 72 | HR sign factor, positivity verification |
| SchoenAlgebraicity | 114 | Norm witnesses, Schoen criterion (3 principled axioms) |
| Pattern | 82 | WeilSelfIntersectionPattern, pattern_verified |
| Verdict | 141 | DPT boundary verification, at_dpt_boundary |
| GramMatrixDerivation | 394 | Conductor-based proof chain (1 principled axiom) |

Two deprecated modules (`Module9_v1_original.lean`, `Module9_v3_deprecated.lean`) are retained for correction history reproducibility.

## AI Assistance

The Lean 4 formalization was produced using AI code generation (Claude Code, Opus 4.6) under human direction. All mathematical content was specified by the author; every theorem is verified by the Lean 4 type checker.
