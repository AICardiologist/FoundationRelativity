# Reproducibility Details — Paper 45

**DOI:** [10.5281/zenodo.18676170](https://doi.org/10.5281/zenodo.18676170)

## Environment

- **Lean 4 version:** leanprover/lean4:v4.28.0 (pinned in `lean-toolchain`)
- **Mathlib:** resolved via `lakefile.lean` from `https://github.com/leanprover-community/mathlib4` (commit pinned in `lake-manifest.json`)
- **LaTeX:** any standard TeX distribution (TeX Live, TinyTeX, MiKTeX) with `pdflatex`

## Reproducing the Lean Build

```bash
cd P45_WMC
lake build
```

On first build, Mathlib will be downloaded and compiled (this may take 30-60 minutes depending on hardware and cache availability). Subsequent builds are incremental.

Expected output: 0 errors, 0 warnings, 0 sorry.

The `#print axioms` commands in `Main.lean` verify the axiom profiles of each theorem at build time.

## Reproducing the Paper

```bash
pdflatex paper45.tex
pdflatex paper45.tex
pdflatex paper45.tex
```

Three passes ensure cross-references and table of contents are fully resolved. The UTF-8 byte warnings from the `listings` package (due to Unicode in Lean code snippets) are cosmetic and do not affect the output PDF.

## Axiom Verification

After building, the Lean kernel has verified:

| Theorem | Custom Axioms | Classical.choice | Classical.dec |
|---------|---------------|-----------------|---------------|
| `WMC_from_five_sublemmas` | 12 (sub-lemma + bridge) | No | No |
| `polarization_forces_degeneration_BISH` (C1) | None | Infrastructure only | No |
| `abstract_degeneration_iff_LPO` (C2) | None | Infrastructure only | No |
| `no_pos_def_hermitian_padic` (C3) | `trace_form_isotropic` | Infrastructure only | No |
| `geometric_degeneration_decidable_BISH` (C4) | 3 (IsGeometric, geometric_differential_decidable, spectral_sequence_bounded) | Infrastructure only | No |
| `constructive_calibration_summary` | C1+C2+C3+C4 combined | Infrastructure only | No |
| `de_omniscientizing_descent` | Same as C2+C4 | Infrastructure only | No |

"Infrastructure only" means Classical.choice appears solely from Mathlib's construction of R and C as Cauchy completions, not from any mathematical omniscience principle.

## AI Assistance

The Lean 4 formalization was produced using AI code generation (Claude Code, Opus 4.6) under human direction. All mathematical content was specified by the author; every theorem is verified by the Lean 4 type checker.
