# Reproducibility Details -- Paper 46

**DOI:** [10.5281/zenodo.18682285](https://doi.org/10.5281/zenodo.18682285)

## Environment

- **Lean 4 version:** leanprover/lean4:v4.29.0-rc1 (pinned in `lean-toolchain`)
- **Mathlib:** resolved via `lakefile.lean` from `https://github.com/leanprover-community/mathlib4` (commit pinned in `lake-manifest.json`)
- **LaTeX:** any standard TeX distribution (TeX Live, TinyTeX, MiKTeX) with `pdflatex`

## Reproducing the Lean Build

```bash
cd P46_Tate
lake build
```

On first build, Mathlib will be downloaded and compiled (this may take 30-60 minutes depending on hardware and cache availability). Subsequent builds are incremental.

Expected output: 0 errors, 0 warnings, 0 sorry.

The `#print axioms` commands in `Main.lean` verify the axiom profiles of each theorem at build time.

## Reproducing the Paper

```bash
pdflatex paper46.tex
pdflatex paper46.tex
pdflatex paper46.tex
```

Three passes ensure cross-references and table of contents are fully resolved.

## Axiom Verification

After building, the Lean kernel has verified:

| Theorem | Custom Axioms | Classical.choice | Classical.dec |
|---------|---------------|-----------------|---------------|
| `galois_invariance_iff_LPO` (T1) | `encode_scalar_to_galois`, `LPO_decides_ker_membership` | Infrastructure only | No |
| `cycle_verification_BISH` (T2) | `ChowGroup`, `intersection` only | Infrastructure only | No |
| `poincare_not_anisotropic` (T3) | `poincare_isotropic_high_dim` | Infrastructure only | No |
| `hom_equiv_requires_LPO` (T4a) | `encode_scalar_to_hom_equiv` | Infrastructure only | No |
| `conjD_decidabilizes_morphisms` (T4b) | `standard_conjecture_D`, `basis_spans_num_equiv` + T2 infra | Infrastructure only | No |
| `tate_calibration_summary` | All of the above combined | Infrastructure only | No |

"Infrastructure only" means Classical.choice appears solely from Mathlib's construction of algebraic structures over fields, not from any mathematical omniscience principle.

## AI Assistance

The Lean 4 formalization was produced using AI code generation (Claude Code, Opus 4.6) under human direction. All mathematical content was specified by the author; every theorem is verified by the Lean 4 type checker.
