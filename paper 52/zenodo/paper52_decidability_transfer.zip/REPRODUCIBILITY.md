# Reproducibility Details — Paper 52

**DOI:** [10.5281/zenodo.18732559](https://doi.org/10.5281/zenodo.18732559)

## Environment

- **Lean 4 version:** leanprover/lean4:v4.29.0-rc1 (pinned in `lean-toolchain`)
- **Mathlib:** resolved via `lakefile.lean` from `https://github.com/leanprover-community/mathlib4` (commit pinned in `lake-manifest.json`)
- **LaTeX:** any standard TeX distribution (TeX Live, TinyTeX, MiKTeX) with `pdflatex`

## Reproducing the Lean Build

```bash
cd P52_DecidabilityTransfer
lake build
```

On first build, Mathlib will be downloaded and compiled (this may take 30-60 minutes depending on hardware and cache availability). Subsequent builds are incremental.

Expected output: 0 errors, 0 warnings, 0 sorry.

The `#print axioms` commands in `Main/AxiomAudit.lean` verify the axiom profiles of each theorem at build time.

## Reproducing the Paper

```bash
pdflatex paper52_decidability_transfer.tex
pdflatex paper52_decidability_transfer.tex
pdflatex paper52_decidability_transfer.tex
```

Three passes ensure cross-references and table of contents are fully resolved. The UTF-8 byte warnings from the `listings` package (due to Unicode in Lean code snippets) are cosmetic and do not affect the output PDF.

## Axiom Verification

After building, the Lean kernel has verified:

| Theorem | Custom Axioms | Classical.choice | Classical.dec |
|---------|---------------|-----------------|---------------|
| `sub_lefschetz_non_degenerate` | 0 | Infrastructure only | No |
| `decidability_transfer_g_le_3` | 0 (3 as hypotheses) | Infrastructure only | No |
| `sharp_boundary_g_eq_4` | 0 (trivially True) | N/A | No |

"Infrastructure only" means Classical.choice appears solely from Mathlib's Field instance and Finset operations, not from any mathematical omniscience principle.

## Formalization Architecture

The formalization uses a **connected architecture**: the main theorem `decidability_transfer_g_le_3` physically invokes `sub_lefschetz_non_degenerate` at Step 5, creating a genuine logical bridge between the geometric hypotheses and the algebraic conclusion. The three geometric inputs (Prop22, Prop21, LefschetzArch) are `def` predicates passed as hypotheses, not `axiom` declarations. This yields zero custom axioms for both theorems.

## AI Assistance

The Lean 4 formalization was produced using AI code generation (Claude Code, Opus 4.6) under human direction. All mathematical content was specified by the author; every theorem is verified by the Lean 4 type checker.
