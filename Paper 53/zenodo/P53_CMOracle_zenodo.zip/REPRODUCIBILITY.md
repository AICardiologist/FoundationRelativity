# Reproducibility Details — Paper 53

**DOI:** [10.5281/zenodo.18713089](https://doi.org/10.5281/zenodo.18713089)

## Environment

- **Lean 4 version:** leanprover/lean4:v4.29.0-rc1 (pinned in `lean-toolchain`)
- **Mathlib:** resolved via `lakefile.lean` from `https://github.com/leanprover-community/mathlib4` (commit pinned in `lake-manifest.json`)
- **LaTeX:** any standard TeX distribution (TeX Live, TinyTeX, MiKTeX) with `pdflatex`

## Reproducing the Lean Build

```bash
cd P53_CMOracle
lake build
```

On first build, Mathlib will be downloaded and compiled (this may take 30-60 minutes depending on hardware and cache availability). Subsequent builds are incremental.

Expected output: 0 errors, 0 warnings, 0 sorry.

The `#print axioms` commands in `Main.lean` verify the axiom profiles of each theorem at build time.

## Reproducing the Paper

```bash
pdflatex paper53_cm_oracle.tex
pdflatex paper53_cm_oracle.tex
pdflatex paper53_cm_oracle.tex
```

Three passes ensure cross-references and table of contents are fully resolved.

## Axiom Verification

After building, the Lean kernel has verified:

| Theorem | Custom Axioms | Classical.choice | Classical.dec |
|---------|---------------|-----------------|---------------|
| `theoremA` (CM oracle) | `decider_correct` | Infrastructure only | No |
| `theoremB` (DPT certificates) | `decider_correct` | Infrastructure only | No |
| `theoremC` (fourfold sign) | **None** | Infrastructure only | No |
| `theoremD` (boundary) | None (documentary) | No | No |

"Infrastructure only" means Classical.choice appears solely from Mathlib's construction of R and C as Cauchy completions, not from any mathematical omniscience principle.

## Key Computational Outputs

The following `#eval` results are produced during the build:

| Computation | Expected | File |
|-------------|----------|------|
| `allCMDecidable` | `true` | Examples.lean |
| `allRosatiPass` | `true` | RosatiCheck.lean |
| `milneH.det` | `1` | MilneExample.lean |
| `crossPairing milneH` | `(7/2, 0)` | SignComputation.lean |
| `weilSelfIntersection milneH` | `7` | SignComputation.lean |
| `hodgeRiemannCheck milneH` | `true` | SignComputation.lean |
| `regressionCheck` | `true` | RegressionTest.lean |

## AI Assistance

The Lean 4 formalization was produced using AI code generation (Claude Code, Opus 4.6) under human direction. All mathematical content was specified by the author; every theorem is verified by the Lean 4 type checker.
